package Product;


import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.table.*;


import Login.*;
import Customer.*;


public class Product extends JFrame implements ActionListener
{
	private JLabel welcomeLabel,nameLabel,priceLabel,qtyLabel,proIdLabel;
    private JTextField nameTf, priceTf,qtyTf,proIdtf;
	private JButton  backBtn, logoutBtn,searchBtn,buyBtn,refreshBtn;
   
	private JTable myTable;
	private JScrollPane tableScrollPane;
	
	private JPanel panel;
	String userId;
	//static int  pid = 1000;
       
	   int avlqnt=0;
	public Product(String userId)
	{
		super("Shop Management System - View Product");
		this.userId = userId;
		
		this.setSize(850, 550);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		welcomeLabel = new JLabel("Welcome, "+userId);
		welcomeLabel.setBounds(0, 0, 100, 30);
		panel.add(welcomeLabel);
		
	
		 myTable = new JTable();
		
		
		
		String []columnNames = {"productId", "productName","price", "AvailableQuantity"};
		
		 DefaultTableModel model = new DefaultTableModel();
         model.setColumnIdentifiers(columnNames);
		
		
		 String query = "select * from Product";
		 
		 Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/f3","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
			System.out.println("results received");
			
			boolean flag = false;
		
			while(rs.next())
			{
               String col1 = rs.getString("productId");
               String col2 = rs.getString("productName");
               String col3 = rs.getString("price");
               String col4 = rs.getString("AvailableQuantity");  
			   model.addRow(new Object[]{col1, col2,col3, col4});
		
			}
			
			myTable.setModel(model);
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            }
            catch(Exception ex)
			{
				
				System.out.println("Exception : " +ex.getMessage());
			}
        }
			
		
	   tableScrollPane = new JScrollPane(myTable);
		tableScrollPane.setBounds(50,200,500,100);
		myTable.setEnabled(false);
		panel.add(tableScrollPane);
		
		
		
		logoutBtn = new JButton("Logout");
		logoutBtn.setBounds(700, 20, 100, 30);
		logoutBtn.addActionListener(this);
		panel.add(logoutBtn);
                
        buyBtn = new JButton("Buy");
		buyBtn.setBounds(630, 100, 100, 30);
        buyBtn.setEnabled(false);
		buyBtn.addActionListener(this);
		panel.add(buyBtn);

		searchBtn = new JButton("Search");
		searchBtn.setBounds(180,100, 100, 30);
		searchBtn.addActionListener(this);
		panel.add(searchBtn);
		
		backBtn = new JButton("Back");
		backBtn.setBounds(350, 400, 120, 30);
		backBtn.addActionListener(this);
		panel.add(backBtn);
		
		
		refreshBtn = new JButton("Refresh");
		refreshBtn.setBounds(50, 50, 100, 30);
		refreshBtn.addActionListener(this);
		panel.add(refreshBtn);
		
        nameLabel = new JLabel("Name: ");
		nameLabel.setBounds(20, 100, 100, 30);
		panel.add(nameLabel);
                
        proIdLabel = new JLabel("ID");
		proIdLabel.setBounds(320, 70, 100, 30);
		panel.add(proIdLabel);
                
        priceLabel = new JLabel("Price");
		priceLabel.setBounds(420, 70, 100, 30);
		panel.add(priceLabel);
                
        qtyLabel = new JLabel("Quantity");
		qtyLabel.setBounds(540, 70, 100, 30);
		panel.add(qtyLabel);
                
        nameTf = new JTextField();
		nameTf.setBounds(70, 100, 100, 30);
		panel.add(nameTf);
                
        proIdtf = new JTextField();
		proIdtf.setBounds(300, 100, 100, 30);
        proIdtf.setEnabled(false);
		panel.add(proIdtf);
                           
        priceTf = new JTextField();
		priceTf.setBounds(410, 100, 100, 30);
        priceTf.setEnabled(false);
		panel.add(priceTf);
                
        qtyTf = new JTextField();
		qtyTf.setBounds(520, 100, 100, 30);
        qtyTf.setEnabled(false);
		panel.add(qtyTf);


		this.add(panel);
	}

	public void actionPerformed(ActionEvent ae)
	{
		String text = ae.getActionCommand();
		
		
		if(text.equals(backBtn.getText()))
		{
			CustomerHome ch = new CustomerHome(userId);
			ch.setVisible(true);
			this.setVisible(false);
		}
		else if(text.equals(logoutBtn.getText()))
		{
			Login lg = new Login();
			lg.setVisible(true);
			this.setVisible(false);
		}
                
                else if(text.equals(searchBtn.getText()))
		{
			loadFromDB();
		}
                else if(text.equals(buyBtn.getText()))
		{
			buyFromDB();
		}

			else if(text.equals(refreshBtn.getText()))
		{
			buyBtn.setEnabled(false);
			proIdtf.setText("");
			nameTf.setText("");
			priceTf.setText("");
			qtyTf.setText("");
		}
           
		
		else{}
	}
        
        

		public void buyFromDB()
		 {
			 	boolean flag=true;
        
        String proid= proIdtf.getText();
        String proname= nameTf.getText();
		
        double price= Double.parseDouble(priceTf.getText());
        int qty= 0;
       
       // pid++;
        //String parid = ""+pid;
		
	
		
		
		while(true){
		try
		{
			qty =Integer.parseInt(qtyTf.getText());
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this, "AvailableQuantity is Integer!!!");
			flag=false;
		    break;
		}
		
		break;
		}
		
		while(true){
			
		if (qty<=0)
		{
			JOptionPane.showMessageDialog(this, " Please Select Quantity ");
			flag=false;
				break;
		}
		else{}
		break;
		
		}
		
		 double amount = price*qty;
	

		
       String qry ="INSERT INTO purchaseinfo (productId,productName,userId,quantity,amount) VALUES ('"+proid+"','"+proname+"','"+ userId+"','"+qty+"','"+amount+"');";
       
	   int val5=avlqnt-qty;
	   
	   	while(true){
			
		if (val5<0)
		{
			JOptionPane.showMessageDialog(this, " Sorry No Product Available ^_^");
			flag=false;
				break;
		}
		else{}
		break;
		
		}
		
	   
	   
       String query2 = "UPDATE `product` SET `availableQuantity` = '"+val5+"' WHERE `product`.`productId` = '"+proid+"';"; 
       Connection con=null;//for connection
        Statement st = null;//for query execution
		System.out.println(qry);
       
	   if(flag){
	   
		try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/f3","root","");
			st = con.createStatement();//create statement
			st.executeUpdate(qry);
			st.executeUpdate(query2);
			st.close();
			con.close();
			JOptionPane.showMessageDialog(this, "Success !!!");
           
		   this.setVisible(false);
           Product ng = new Product(userId);
		    ng.setVisible(true);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			JOptionPane.showMessageDialog(this, "Oops !!!");
		}
        
         }
        
}
		
		
		
        public void loadFromDB()
	{
		String loadname = nameTf.getText();
		String query = "SELECT  `price`, `availableQuantity`, `productId` FROM `product` WHERE `productName`='"+loadname+"';";    

        
		
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/f3","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
			System.out.println("results received");
			
			boolean flag = false;
			String proname = null;
			double price = 0;
			int avlq = 0;
           String proid=null;
           buyBtn.setEnabled(true);
           qtyTf.setEnabled(true);

			
			while(rs.next())
			{

				price = rs.getDouble("price");
				avlq = rs.getInt("availableQuantity");
                                proid= rs.getString("productId");
                                
                                avlqnt=avlq;
				flag=true;
				

				priceTf.setText(""+price);
				qtyTf.setText(""+avlq);
                                
              proIdtf.setText(proid);
                                
			}
			if(!flag)
			{

				priceTf.setText("");
				qtyTf.setText("");

				JOptionPane.showMessageDialog(this,"Invalid ID"); 
			}
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            }
            catch(Exception ex){}
        }
	}
        

}
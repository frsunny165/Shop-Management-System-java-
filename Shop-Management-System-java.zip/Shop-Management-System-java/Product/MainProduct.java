package Product;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.table.*;

import Login.*;
import Employee.*;


public class MainProduct extends JFrame implements ActionListener
{
	JLabel welcomeLabel,proName, proId,proPrice,availableQnt;
	private JButton  backBtn, logoutBtn,updateBtn, delBtn,addBtn,loadBtn,refreshBtn;
        private JTextField proNametf, proIdtf,proPricetf,availableQnttf;
        
   
	private JTable myTable;
	private JScrollPane tableScrollPane;
	
	private JPanel panel;
	String userId;
	
	public MainProduct(String userId)
	{
		super("Shop Management System - View Product");
		this.userId = userId;
		
		this.setSize(1000, 500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		welcomeLabel = new JLabel("Welcome, "+userId);
		welcomeLabel.setBounds(0, 0, 100, 30);
		panel.add(welcomeLabel);
                
		
	
		 myTable = new JTable();
		
		
		
		String []columnNames = {"productId", "productName","price", "AvailableQuantity"};
		
		 DefaultTableModel model = new DefaultTableModel();
         model.setColumnIdentifiers(columnNames);
		
		
		 String query = "select * from Product";
		 
		 Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/f3","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
			System.out.println("results received");
			
			boolean flag = false;
		
			while(rs.next())
			{
               String col1 = rs.getString("productId");
               String col2 = rs.getString("productName");
               String col3 = rs.getString("price");
               String col4 = rs.getString("AvailableQuantity");  
			   model.addRow(new Object[]{col1, col2,col3, col4});
		
			}
			
			myTable.setModel(model);
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            }
            catch(Exception ex)
			{
				
				System.out.println("Exception : " +ex.getMessage());
			}
        }
			
		
	   tableScrollPane = new JScrollPane(myTable);
		tableScrollPane.setBounds(450,50,500,100);
		myTable.setEnabled(false);
		panel.add(tableScrollPane);
		
		
		
		logoutBtn = new JButton("Logout");
		logoutBtn.setBounds(800, 0, 100, 30);
		logoutBtn.addActionListener(this);
		panel.add(logoutBtn);
		
        loadBtn = new JButton("Load");
		loadBtn.setBounds(300, 50, 100, 30);
		loadBtn.addActionListener(this);
		panel.add(loadBtn);
                
		backBtn = new JButton("Back");
		backBtn.setBounds(800, 400, 120, 30);
		backBtn.addActionListener(this);
		panel.add(backBtn);
		
		updateBtn = new JButton("update");
		updateBtn.setBounds(300, 100, 120, 30);
		updateBtn.addActionListener(this);
        updateBtn.setEnabled(false);
		panel.add(updateBtn);
		
		addBtn = new JButton("Add");
		addBtn.setBounds(300, 150, 120, 30);
		addBtn.addActionListener(this);
		panel.add(addBtn);
		
		
		
		delBtn = new JButton("Delete");
		delBtn.setBounds(300, 200, 120, 30);
        delBtn.setEnabled(false);
		delBtn.addActionListener(this);
		panel.add(delBtn);
		
		
		refreshBtn = new JButton("Refresh");
		refreshBtn.setBounds(100, 250, 100, 30);
		refreshBtn.addActionListener(this);
		panel.add(refreshBtn);
                
 
                
         proName = new JLabel("Name:");
		proName.setBounds(20, 100, 100, 30);
		panel.add(proName);
                
		proId = new JLabel("ID:");
		proId.setBounds(20, 50, 100, 30);
		panel.add(proId);
                
		proPrice = new JLabel("Price:");
		proPrice.setBounds(20, 150, 100, 30);
		panel.add(proPrice);
                
		availableQnt = new JLabel("Availabe:");
		availableQnt.setBounds(20, 200, 100, 30);
		panel.add(availableQnt);
                
        proNametf = new JTextField();
		proNametf.setBounds(100, 100, 100, 30);
		panel.add(proNametf);
                
        proIdtf = new JTextField();
		proIdtf.setBounds(100, 50, 100, 30);
		panel.add(proIdtf);
                
        proPricetf = new JTextField();
		proPricetf.setBounds(100, 150, 100, 30);
		panel.add(proPricetf);
                
        availableQnttf = new JTextField();
		availableQnttf.setBounds(100, 200, 100, 30);
		panel.add(availableQnttf);
                
		
		this.add(panel);
	}

	public void actionPerformed(ActionEvent ae)
	{
		String text = ae.getActionCommand();
		
		
		if(text.equals(backBtn.getText()))
		{
			EmployeeHome eh = new EmployeeHome(userId);
			eh.setVisible(true);
			this.setVisible(false);
		}
		else if(text.equals(logoutBtn.getText()))
		{
			Login lg = new Login();
			lg.setVisible(true);
			this.setVisible(false);
		}
		else if(text.equals(updateBtn.getText())){
			updateInDB();
			
			
		}
                else if(text.equals(loadBtn.getText())){
			loadFromDB();
			
			
		}
                else if(text.equals(delBtn.getText())){
			DeleteFromDB();
			
			
		}
          else if(text.equals(addBtn.getText())){
			AddInDB();
			
			
		}
		
		else if(text.equals(refreshBtn.getText()))
		{
			updateBtn.setEnabled(false);
			delBtn.setEnabled(false);
			proIdtf.setEnabled(true);
			proIdtf.setText("");
			proNametf.setText("");
			proPricetf.setText("");
			availableQnttf.setText("");
		}
                
              
		
		else{}
	}
	
	
	
	
	public void updateInDB() 
	
	{
		boolean flag=true;
		
        String name= proNametf.getText();
        String pid= proIdtf.getText();
        double price= 0.0;
        int qnttf= 0;
		
		
		
		
		
		while(true){
		
		try
		{
			price = Double.parseDouble(proPricetf.getText());
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this, "Price is Double!!!");
			flag=false;
				break;
			
		}
		try
		{
			qnttf =Integer.parseInt(availableQnttf.getText());
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this, "AvailableQuantity is Integer!!!");
			flag=false;
			break;
		}
			break;
		}
		
		
		
		
		
		
		
        
       String query ="UPDATE product SET productId='"+pid+"', productName = '"+name+"', price = '"+price+"', availableQuantity = "+qnttf+" WHERE productId='"+pid+"'";
        Connection con=null;//for connection
        Statement st = null;//for query execution
		System.out.println(query);
         
		
		  if(flag){
		try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/f3","root","");
			st = con.createStatement();//create statement
			st.executeUpdate(query);
			st.close();
			con.close();
			JOptionPane.showMessageDialog(this, "Success !!!");
			
			
	  
		   this.setVisible(false);
            MainProduct ng = new MainProduct(userId);
		    ng.setVisible(true);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			JOptionPane.showMessageDialog(this, "Oops !!!");
		}
		  }
        
    }
        
		
		
		
		
	
	public void AddInDB() 
		{
		
		boolean flag=true;
			
        String name= proNametf.getText();
        String pid= proIdtf.getText();
        double price=0.0;
        int qnttf= 0;
		
		while(true){
		
		try
		{
			price = Double.parseDouble(proPricetf.getText());
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this, "Price is Double!!!");
			flag=false;
				break;
			
		}
		try
		{
			qnttf =Integer.parseInt(availableQnttf.getText());
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this, "AvailableQuantity is Integer!!!");
			flag=false;
			break;
		}
			break;
		}
		
        
       String query ="INSERT INTO product VALUES ('"+pid+"','"+name+"','"+ price+"','"+qnttf+"');";
        Connection con=null;//for connection
        Statement st = null;//for query execution
		System.out.println(query);
		
		while(true){
		if(name.length()==0)
		{
		JOptionPane.showMessageDialog(null,"You must provide Name");
          flag=false;
		    break;
	
		}
        if(pid.length()==0){
			JOptionPane.showMessageDialog(null,"You must provide ID");
	         	flag=false;
				 break;   
		}
			
		break;
		}
         
		
		if(flag){
			
		try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/f3","root","");
			st = con.createStatement();//create statement
			st.executeUpdate(query);
			st.close();
			con.close();
			JOptionPane.showMessageDialog(this, "Success !!!");
              
		

			  this.setVisible(false);
               MainProduct ng = new MainProduct(userId);
		       ng.setVisible(true);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			JOptionPane.showMessageDialog(this, "Oops !!!");
		}
		}
        
    }
        
       






	   public void loadFromDB()
	{
		String loadId = proIdtf.getText();
		String query = "SELECT `productName`, `price`, `availableQuantity` FROM `product` WHERE `productId`='"+loadId+"';";    

        
		
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/f3","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
			System.out.println("results received");
			
			boolean flag = false;
			String proname = null;
			double price = 0;
			int avlq = 0;
			
			while(rs.next())
			{
                //eName = rs.getString("employeeName");
				proname = rs.getString("productName");
				price = rs.getDouble("price");
				avlq = rs.getInt("availableQuantity");
				flag=true;
				
				proNametf.setText(proname);
				proPricetf.setText(""+price);
				availableQnttf.setText(""+avlq);
				proIdtf.setEnabled(false);
				updateBtn.setEnabled(true);
				delBtn.setEnabled(true);
			}
			if(!flag)
			{
				proNametf.setText("");
				proPricetf.setText("");
				availableQnttf.setText("");

				JOptionPane.showMessageDialog(this,"Invalid ID"); 
			}
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            }
            catch(Exception ex){}
        }
	}
        
		
		
		
		
		
		
		
        public void DeleteFromDB() {
		String newId = proIdtf.getText();
		String query1 = "DELETE from product WHERE productId='"+newId+"';";
		System.out.println(query1);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/f3", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query1);
			stm.close();
			con.close();
			JOptionPane.showMessageDialog(this, "Success !!!");
		        this.setVisible(false);
                       MainProduct lg = new MainProduct(userId);
		       lg.setVisible(true);

		}
        catch(Exception ex)
		{
			JOptionPane.showMessageDialog(this, "Oops !!!");
        }
	}

    
}
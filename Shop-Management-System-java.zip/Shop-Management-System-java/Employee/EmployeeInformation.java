package Employee;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

import Login.*;

public class EmployeeInformation extends JFrame implements ActionListener
{
	private JLabel userLabel1,userLabel2, salaryLabel, roleLabel, phonenoLabel;
	private JTextField   userTF2,userTF, salaryTF, roleTF, phonenoTF1,phonenoTF2;
	private JButton autoPassBtn, backBtn, logoutBtn;
	private JPanel panel;
	String userId;
	
	public EmployeeInformation(String userId)
	{
		super("Shop Management System - Employee Information");
		
		this.setSize(850, 550);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.userId = userId;
		
		panel = new JPanel();
		panel.setLayout(null);
		
		logoutBtn = new JButton("Logout");
		logoutBtn.setBounds(600, 50, 100, 30);
		logoutBtn.addActionListener(this);
		panel.add(logoutBtn);
		
		
		userLabel1 = new JLabel("User Name: ");
		userLabel1.setBounds(150, 90, 120, 30);
		panel.add(userLabel1);
		
		salaryLabel = new JLabel("Salary : ");
		salaryLabel.setBounds(150, 130, 120, 30);
		panel.add(salaryLabel);
		
		phonenoLabel = new JLabel("Phone No. : ");
		phonenoLabel.setBounds(150, 170, 120, 30);
		panel.add(phonenoLabel);
		
		
		roleLabel = new JLabel("Role : ");
		roleLabel.setBounds(150, 210, 120, 30);
		panel.add(roleLabel);
		
		userTF = new JTextField();
		userTF.setBounds(260, 90, 150, 30);
		panel.add(userTF);
			
		
		salaryTF = new JTextField();
		salaryTF.setBounds(260, 130, 150, 30);
		panel.add(salaryTF);
		
		phonenoTF1 = new JTextField("+880");
		phonenoTF1.setBounds(260, 170, 35, 30);
		phonenoTF1.setEnabled(false);
		//phonenoTF1.setForeground(Color.BLACK);
		panel.add(phonenoTF1);
		
		phonenoTF2 = new JTextField();
		phonenoTF2.setBounds(295, 170, 115, 30);
		panel.add(phonenoTF2);
		
		roleTF = new JTextField();
		roleTF.setBounds(260, 210, 115, 30);
		panel.add(roleTF);
		
		
		backBtn = new JButton("Back");
		backBtn.setBounds(350, 400, 100, 30);
		backBtn.addActionListener(this);
		panel.add(backBtn);
		
		loadFromDB();
		this.add(panel);
	}
	
	public void loadFromDB()
	{
		String query = "SELECT * from EMPLOYEE where userId ='"+this.userId+"'";
		
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/f3","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
			System.out.println("results received");
			
			boolean flag = false;
			String eName = null;
			String phnNo = null;
			String role = null;
			double salary = 0.0;			
			while(rs.next())
			{
               eName  = rs.getString("employeeName");
				phnNo = rs.getString("phoneNumber");
				role = rs.getString("role");
				salary = rs.getDouble("salary");
				flag=true;
				
				userTF.setText(eName);
				phonenoTF1.setText("+880");
				phonenoTF2.setText(phnNo.substring(4,14));
				roleTF.setText(role);
				salaryTF.setText(""+salary);
				
				
			}
			if(!flag)
			{
				userTF.setText("");
				phonenoTF1.setText("");
				phonenoTF2.setText("");
				roleTF.setText("");
				salaryTF.setText("");
				JOptionPane.showMessageDialog(this,"Invalid ID"); 
			}
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();

                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            }
            catch(Exception ex)
			{
				
				System.out.println("Exception : " +ex.getMessage());
			}
        }
		
		
		
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		String text = ae.getActionCommand();
		
		
		if(text.equals(backBtn.getText()))
		{
			EmployeeHome eh = new EmployeeHome(userId);
			eh.setVisible(true);
			this.setVisible(false);
		}
		else if(text.equals(logoutBtn.getText()))
		{
			Login lg = new Login();
			lg.setVisible(true);
			this.setVisible(false);
		}
		
		else{}
	}
	
		
		
		
	
	
	
}
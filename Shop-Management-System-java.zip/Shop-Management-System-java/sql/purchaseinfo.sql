-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 02, 2018 at 10:20 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `f3`
--

-- --------------------------------------------------------

--
-- Table structure for table `purchaseinfo`
--

CREATE TABLE `purchaseinfo` (
  `purchaseId` int(50) NOT NULL,
  `productId` varchar(10) NOT NULL,
  `productName` varchar(25) NOT NULL,
  `userId` varchar(25) NOT NULL,
  `quantity` int(15) NOT NULL,
  `amount` double(8,2) NOT NULL,
  `purchaseDate` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchaseinfo`
--

INSERT INTO `purchaseinfo` (`purchaseId`, `productId`, `productName`, `userId`, `quantity`, `amount`, `purchaseDate`) VALUES
(6, '1002', 'Shampoo', 'fr', 6, 2400.00, '2018-09-02 19:46:36.658427'),
(7, '1002', 'Shampoo', 'fr', 1, 400.00, '2018-09-02 19:56:42.498260'),
(8, '1011', 'asus rog ', 'fr', 1, 85000.00, '2018-09-02 19:56:52.081703'),
(9, '1010', 'xbox360 controller', 'fr', 2, 2400.00, '2018-09-02 19:57:02.430949'),
(10, '1009', 'fifa 19 cd key', 'fr', 3, 12600.00, '2018-09-02 19:57:22.474479'),
(11, '1007', 'ps4', 'fr', 1, 25000.00, '2018-09-02 19:57:36.506092'),
(12, '1006', 'Game Pad', 'fr', 4, 16000.00, '2018-09-02 19:57:49.241945'),
(13, '1002', 'Shampoo', 'rakib', 9, 3600.00, '2018-09-02 20:00:31.857463'),
(14, '1001', 'Soap', 'fr', 3, 450.00, '2018-09-02 20:18:02.554590');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `purchaseinfo`
--
ALTER TABLE `purchaseinfo`
  ADD PRIMARY KEY (`purchaseId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `purchaseinfo`
--
ALTER TABLE `purchaseinfo`
  MODIFY `purchaseId` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

package Customer;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.util.*;

import Login.*;
import Product.*;

public class CustomerHome extends JFrame implements ActionListener
{
	JLabel welcomeLabel;
	private JLabel userLabel;
	private JButton PurchasesBtn, PurchasesInformationBtn, changePasswordBtn, CustomerInformationBtn, logoutBtn;
	private JPanel panel;
	//private String userId;

	String userId;
	
	public CustomerHome(String userId)
	{
		super("Customer managemant - CustomerHome Window");
		this.userId = userId;
		
		this.setSize(850,550);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		
		
		userLabel = new JLabel("Welcome, "+userId);
		userLabel.setBounds(180, 20, 350, 70);
		panel.add(userLabel);
		
		logoutBtn = new JButton("Logout");
		logoutBtn.setBounds(600, 40, 100, 30);
		logoutBtn.addActionListener(this);
		panel.add(logoutBtn);
		
		PurchasesBtn = new JButton("Purchases");
		PurchasesBtn.setBounds(100, 100, 100, 30);
		PurchasesBtn.addActionListener(this);
		panel.add(PurchasesBtn);
		
		PurchasesInformationBtn = new JButton("purchases Information");
		PurchasesInformationBtn.setBounds(100, 150, 200, 30);
		PurchasesInformationBtn.addActionListener(this);
		panel.add(PurchasesInformationBtn);
		
		changePasswordBtn = new JButton("Change Password");
		changePasswordBtn.setBounds(600, 100, 150, 30);
		changePasswordBtn.addActionListener(this);
		panel.add(changePasswordBtn);
		
		
		CustomerInformationBtn = new JButton("My Information");
		CustomerInformationBtn.setBounds(600, 150, 150, 30);
		CustomerInformationBtn.addActionListener(this);
		panel.add(CustomerInformationBtn);
		
		
		
		this.add(panel);
	}
	
	public void actionPerformed(ActionEvent ae)
	{
		String text = ae.getActionCommand();
		
		if(text.equals(logoutBtn.getText()))
		{
			Login lg = new Login();
			lg.setVisible(true);
			this.setVisible(false);
		}
		else if(text.equals(changePasswordBtn.getText()))
		{
			ChangePassword cp = new ChangePassword(userId);
			cp.setVisible(true);
			this.setVisible(false);
		}
		
		else if(text.equals(CustomerInformationBtn.getText()))
			{
			CustomerInformation ci = new CustomerInformation(userId);
			ci.setVisible(true);
			this.setVisible(false);
			}
		else if(text.equals(PurchasesInformationBtn.getText()))
			{
			PurchasesInformation pi = new PurchasesInformation(userId);
			pi.setVisible(true);
			this.setVisible(false);
			}
			else
			{
			Product pi = new Product(userId);
			pi.setVisible(true);
			this.setVisible(false);
			}
		}
	}
	
package Customer;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.util.*;

import Login.*;

public class ChangePassword extends JFrame implements ActionListener,MouseListener
{
	JLabel welcomeLabel;
	private JLabel oldPassLabel, newPassLabel;
	private JPasswordField oldPassPF, newPassPF;
	private JButton changeBtn, backBtn, logoutBtn,confirmBtn,showpasswordBtn1,showpasswordBtn;
    private JPanel panel;

	String userId;
	
	private String status;
	private int access=0;
	public ChangePassword(String userId)
	{
		super("Customer management System - Change Password Window");
		this.userId = userId;
		
		this.setSize(850,550);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		panel = new JPanel();
		panel.setLayout(null);
		
		
		
		welcomeLabel = new JLabel("Welcome, "+userId);
		welcomeLabel.setBounds(350, 50, 100, 30);
		panel.add(welcomeLabel);
		
		
		oldPassLabel = new JLabel("Old Password :");
		oldPassLabel.setBounds(70, 100, 200, 30);
		
		panel.add(oldPassLabel);
		
		newPassLabel = new JLabel("New Password :");
		newPassLabel.setBounds(70, 150, 200, 30);
		
		panel.add(newPassLabel);
		
	     
		oldPassPF = new JPasswordField();
		oldPassPF.setBounds(290, 100, 130, 30);
		panel.add(oldPassPF);
		
		
		newPassPF = new JPasswordField();
		newPassPF.setBounds(290, 150, 130, 30);
		panel.add(newPassPF);
		
		
		showpasswordBtn = new JButton("Show Pass");
		showpasswordBtn.setBounds(450, 100, 100, 30);
		showpasswordBtn.addMouseListener(this);
		panel.add(showpasswordBtn);
		
		showpasswordBtn1 = new JButton("Show Pass");
		showpasswordBtn1.setBounds(450, 150, 100, 30);
		showpasswordBtn1.addMouseListener(this);
		panel.add(showpasswordBtn1);
		
		confirmBtn = new JButton("Confirm");
		confirmBtn.setBounds(200, 350, 130, 40);
		confirmBtn.addActionListener(this);
		panel.add(confirmBtn);
		
		
		
		
		backBtn = new JButton("Back");
		backBtn.setBounds(459,350, 130, 40);
		backBtn.addActionListener(this);
		panel.add(backBtn);
		
		
		
		logoutBtn = new JButton("Logout");
		logoutBtn.setBounds(600, 50, 100, 30);
		logoutBtn.addActionListener(this);
		panel.add(logoutBtn);
		
		
		
		this.add(panel);
	}
	
	
	
	public void mouseEntered(MouseEvent me){}
	public void mouseExited(MouseEvent me){}
	public void mouseClicked(MouseEvent me){}
	public void mouseReleased(MouseEvent me)
	{
		if(me.getSource().equals(showpasswordBtn))
		{
			oldPassPF.setEchoChar('*');
		}
		
		if(me.getSource().equals(showpasswordBtn1))
		{
			newPassPF.setEchoChar('*');
		}
		
		
	}
	public void mousePressed(MouseEvent me)
	{
		if(me.getSource().equals(showpasswordBtn))
		{
			oldPassPF.setEchoChar((char)0);
		}
		
		if(me.getSource().equals(showpasswordBtn1))
		{
			newPassPF.setEchoChar((char)0);
		}
	}

	
	
public void actionPerformed(ActionEvent ae)
	{
		String text = ae.getActionCommand();
		
		
		if(text.equals(backBtn.getText()))
		{
			CustomerHome ch = new CustomerHome(userId);
			ch.setVisible(true);
			this.setVisible(false);
		}
		
		if(text.equals(logoutBtn.getText()))
		{
			Login lg = new Login();
			lg.setVisible(true);
			this.setVisible(false);
		}
		
		if(text.equals(confirmBtn.getText()))
		{
			confirmFromDB();
			if(access==1){
				updateInDB();
				
				access = 0;
			}
			else if(access==0){
				JOptionPane.showMessageDialog(this," Old password didn't match!");
			}
		}
	
	}
	
	public void confirmFromDB()
	
	{

		 String query = "SELECT password,`status`  FROM Login where `userId`='"+userId+"';";
        Connection con=null;//for connection
        Statement st = null;//for query execution
		ResultSet rs = null;//to get row by row result from DB
		System.out.println(query);
        
		 
		
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/f3","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			rs = st.executeQuery(query);//getting result
			System.out.println("results received");
			while(rs.next()){
				String password = rs.getString("password");
				status = rs.getString("status");
				if(password.equals(oldPassPF.getText()))
				{
					access = 1;
					System.out.println("pass: "+password);
				}
			}
		}
        catch(Exception ex)
		{
			System.out.println("Exception : " +ex.getMessage());
			
        }
        finally
		{
            try
			{
                if(rs!=null)
					rs.close();
                if(st!=null)
					st.close();

                if(con!=null)
					con.close();
            }
            catch(Exception ex){}
        }
		
		
	}
	
	public void updateInDB()
	{
        Connection con=null;//for connection
        Statement st = null;//for query execution
        
		String newPass = newPassPF.getText();
		
		String oldPass = oldPassPF.getText();
		
		 boolean flag=true;
		 
		 if(newPass.equals(oldPass))
		{
		JOptionPane.showMessageDialog(null,"This is your Old  password ");
          flag=false;
		  	
		}
		
		 
		
		if(newPass.length()==0)
		{
		JOptionPane.showMessageDialog(null,"You must provide new password ");
          flag=false;
		  	
		}
		
		
		 if(flag){
		try
		{
			
			Class.forName("com.mysql.jdbc.Driver");//load driver
			System.out.println("driver loaded");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/f3","root","");
			System.out.println("connection done");//connection with database established
			st = con.createStatement();//create statement
			System.out.println("statement created");
			String query = "UPDATE Login SET password="+newPass+" where `userId`='"+userId+"';";
			st.executeUpdate(query);
			System.out.println(query);
			st.close();
			con.close();
			
			JOptionPane.showMessageDialog(this,"new password has been changed successfuly!");
			
			Login lg = new Login();
			lg.setVisible(true);
			this.setVisible(false);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			
			}
		 }
	}
	
		
	
	
	
	
	
	
	
	
	
	
}

package Login;

import java.lang.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import java.util.*;

import Employee.*;
import Customer.*;




public class RegPage extends JFrame implements ActionListener,MouseListener
{
	JLabel userLabel, passLabel, cNameLabel, phoneLabel,addressLabel;
	JTextField userTF,  phoneTF1, phoneTF2,cNameTF, addressTF;
	JComboBox roleCombo;
	JButton showpasswordBtn, submitBtn, cancelButton;
	
	JPasswordField passPF;
	
	JPanel panel;
	String userId;
	
	public RegPage()
	{
		super("Shop Management System - Sign up");
		
		this.setSize(800, 500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.userId = userId;
		
		panel = new JPanel();
		panel.setLayout(null);
			
		userLabel = new JLabel("User ID : ");
		userLabel.setBounds(250, 100, 120, 30);
		panel.add(userLabel);
		
		userTF = new JTextField();
		userTF.setBounds(400, 100, 120, 30);
		panel.add(userTF);
		
		passLabel = new JLabel("Password : ");
		passLabel.setBounds(250, 150, 120, 30);
		panel.add(passLabel);
		
		passPF = new JPasswordField();
		passPF.setBounds(400, 150, 120, 30);
		passPF.setEchoChar('*');
		//passPF.setEnabled(false);
		panel.add(passPF);
		
		showpasswordBtn = new JButton("Show Pass");
		showpasswordBtn.setBounds(550, 150, 100, 30);
		showpasswordBtn.addMouseListener(this);
		panel.add(showpasswordBtn);
		
		cNameLabel = new JLabel("Customer Name : ");
		cNameLabel.setBounds(250, 200, 120, 30);
		panel.add(cNameLabel);
		
		cNameTF = new JTextField();
		cNameTF.setBounds(400, 200, 120, 30);
		panel.add(cNameTF);
		
		phoneLabel = new JLabel("Phone No. : ");
		phoneLabel.setBounds(250, 250, 120, 30);
		panel.add(phoneLabel);
		
		phoneTF1 = new JTextField("+880");
		phoneTF1.setBounds(400, 250, 35, 30);
		phoneTF1.setEnabled(false);
		phoneTF1.setForeground(Color.BLACK);
		panel.add(phoneTF1);
		
		phoneTF2 = new JTextField();
		phoneTF2.setBounds(435, 250, 85, 30);
		panel.add(phoneTF2);
				
		addressLabel = new JLabel("address : ");
		addressLabel.setBounds(250, 350, 120, 30);
		panel.add(addressLabel);
		
		addressTF = new JTextField();
		addressTF.setBounds(400, 350, 120, 30);
		panel.add(addressTF);
		
		submitBtn = new JButton("Submit");
		submitBtn.setBounds(250, 400, 120, 30);
		submitBtn.addActionListener(this);
		panel.add(submitBtn);
		
		cancelButton = new JButton("Cancel");
		cancelButton.setBounds(400, 400, 120, 30);
		cancelButton.addActionListener(this);
		panel.add(cancelButton);
		
		this.add(panel);
	}
	
	
	public void mouseEntered(MouseEvent me){}
	public void mouseExited(MouseEvent me){}
	public void mouseClicked(MouseEvent me){}
	public void mouseReleased(MouseEvent me)
	{
		if(me.getSource().equals(showpasswordBtn))
		{
			passPF.setEchoChar('*');
		}
	}
	public void mousePressed(MouseEvent me)
	{
		if(me.getSource().equals(showpasswordBtn))
		{
			passPF.setEchoChar((char)0);
		}
	}

	
	
	
	
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String text = ae.getActionCommand();
		
		if(text.equals(cancelButton.getText()))
		{
			Login lg = new Login();
			lg.setVisible(true);
			this.setVisible(false);
		}
		
		else if(text.equals(submitBtn.getText()))
		{
			insertIntoDB();
		}
		else{}
	}
	
	 
	
	
	public void insertIntoDB()
	{
		 boolean flag=true;
		 
		String newId = userTF.getText();
		String newPass = passPF.getText();
		String cName = cNameTF.getText();
		//String phnNo = phoneTF1.getText()+Integer.parseInt(phoneTF2.getText());
		String address =  addressTF.getText();
		int status = 1;
		String phnNo1 =phoneTF2.getText();
		String phnNo = "";
		try
		{
			phnNo = phoneTF1.getText()+Integer.parseInt(phoneTF2.getText());
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(this, "Phone number  is Integer!!!");
			flag=false;
			
		}
		
		
		String query1 = "INSERT INTO customer VALUES ('"+newId+"','"+cName+"','"+ phnNo+"','"+address+"');";
		String query2 = "INSERT INTO Login VALUES ('"+newId+"','"+newPass+"','"+status+"');";
		System.out.println(query1);
		System.out.println(query2);
		
        if(newId.length()==0)
		{
		JOptionPane.showMessageDialog(null,"You must provide ID");
          flag=false;
		   
	
		}
        if(newPass.length()==0){
			JOptionPane.showMessageDialog(null,"You must provide Password");
	         	flag=false;
				
              
		}

	if(cName.length()==0){
			JOptionPane.showMessageDialog(null,"You must provide Name");
	         flag=false;
			
                     
		}
	if(phnNo1.length()==0){
			JOptionPane.showMessageDialog(null,"You must provide phone Number");
				flag=false;
			
             
		}
		if(address.length()==0){
			JOptionPane.showMessageDialog(null,"You must provide Address ");
				flag=false;
				
                
		}
      
	   
	   
		 if(flag){
        try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/f3", "root", "");
			Statement stm = con.createStatement();
			stm.execute(query1);
			stm.execute(query2);
			stm.close();
			con.close();
			JOptionPane.showMessageDialog(this, "Success !!!");
			Login lg = new Login();
			lg.setVisible(true);
			this.setVisible(false);
			
		}
        catch(Exception ex)
		{
			//System.out.println("Exception : " +ex.getMessage());
			JOptionPane.showMessageDialog(this, "Oops !!!");
        }
		 }
    }
 
        
}
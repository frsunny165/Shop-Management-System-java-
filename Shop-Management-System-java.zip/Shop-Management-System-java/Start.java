import java.lang.*;

import Login.*;
import Employee.*;
import Customer.*;
import Product.*;

public class Start
{
	static public void main(String args[])
	{
		Login lg = new Login();
		lg.setVisible(true);
	}
}